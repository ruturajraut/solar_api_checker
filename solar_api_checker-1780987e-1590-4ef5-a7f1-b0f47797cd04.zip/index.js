var AWS = require("aws-sdk");
var https = require('https');
var mysql = require('mysql');
// var nodemailer = require('nodemailer')
var ses = new AWS.SES({region: 'ap-south-1'});
var connection;


exports.handler = (event, context, callback) => {
    
            //console.log("Event",event)

            if(!event.hasOwnProperty("solar_api_checker")){
                callback("Valid parameter not found");
                return;
            }
            
            const nowMilliSecs = Date.now();
            console.log('Current timestamp:', nowMilliSecs);
            
            const yesterday = new Date();
            yesterday.setDate(yesterday.getDate() - 1);
            
            const yesterdayText = formatDate(yesterday);
            console.log("yesterday",yesterday)
            var yesterDayFancyText = formatDateFancy(yesterday);
            
            var mailContent = '';
            
            var subject = `AI Alerts : Solar Generation data from Trackso API `
                                    
            var emailIDArr = [
            "ruturajraut2000@gmail.com",
            //"gautam@claypot.in",
            //"chauhan@claypot.in",
            //"tech-assist@claypot.in",
            //"yogesh@claypot.in"
            
            ];
            
            
            //const yesterdayText = formatDate(yesterday);
            //var yesterDayFancyText = formatDateFancy(yesterday);
            
            console.log("yesterdayText",yesterdayText)
            console.log("yesterDayFancyText",yesterDayFancyText)
            
            yesterday.setHours(0);
            yesterday.setMinutes(0);
            yesterday.setSeconds(0);
            
            // yesterday.setHours(yesterday.getHours() - 5);
            // yesterday.setMinutes(yesterday.getMinutes() - 30);
            
            console.log(yesterday);
            var startEpoch = Math.round(yesterday.valueOf() / 1000);
            console.log("startEpoch",startEpoch);
            
            yesterday.setHours(23);
            yesterday.setMinutes(58);
            yesterday.setSeconds(00);
            
            console.log(yesterday);
            var endEpoch = Math.round(yesterday.valueOf() / 1000);
            console.log("endEpoch",endEpoch);
            
            var ohp_site_id = "fa423a8e55";
            const ohp_unit_cost = 22.76;
            const ohp_capex = 2730000;
            const ohp_installed_capacity = 34.50;
            const ohp_installed_date = "June 1st, 2023";
            
            var jana_site_id = "05e17b0001";
            const jana_unit_cost = 9.70;
            const jana_capex = 682224;
            const jana_installed_capacity = 10.00;
            const jana_installed_date = "March 1st, 2023";
            
            var meadows_site_id = "01b9e18a21"
            const meadows_unit_cost = 20.60;
            const meadows_capex = 5875000;
            const meadows_installed_capacity = 85.25;
            const meadows_installed_date = "July 4th, 2023";
            
            var clifton_site_id= "82580871dd";
            const clifton_unit_cost = 19.26;
            const clifton_capex = 2502000;
            const clifton_installed_capacity = 21.25;
            const clifton_installed_date = "Oct 9th, 2023";
            
            var np_site_id= "a48403f527";
            const np_unit_cost = 17.23;
            const np_capex = 4488892;
            const np_installed_capacity = 55.90;
            const np_installed_date = "Dec 22nd, 2023";
            
            var zenia_site_id= "25041efc9b";
            const zenia_unit_cost = 21.23;
            const zenia_capex = 4762400;
            const zenia_installed_capacity = 47.96;
            const zenia_installed_date = "Dec 12th, 2023";
            
            var bellona_site_id= "ba468d52e2";
            const bellona_unit_cost = 20.78;
            const bellona_capex = 6956000;
            const bellona_installed_capacity = 116.63;
            const bellona_installed_date = "Apr 5th, 2024";
            
            var quantum_site_id= "034e55921c";
            const quantum_unit_cost = 22;
            const quantum_capex = 13995000;
            const quantum_installed_capacity = 177.67;
            const quantum_installed_date = "Apr 5th, 2024";
            
            var tiffany_site_id= "375a9e9d80";
            const tiffany_unit_cost = 17.97;
            const tiffany_capex = 1549000;
            const tiffany_installed_capacity = 21.8;
            const tiffany_installed_date = "Apr 11th, 2024";
            
            var hamiltonA_site_id= "990201078b";
            const hamiltonA_unit_cost = 18.33;
            const hamiltonA_capex = 850000;
            const hamiltonA_installed_capacity = 13.08;
            const hamiltonA_installed_date = "Apr 20th, 2024";
            
            
            var emailerrorlist = [];
            
            try{
            tracksoLogin(async function(err,loginData){
                if(err){
                    console.log("error while logging into trackso API");
                    return;
                }
                // console.log(data);
                loginData = JSON.parse(loginData);
                // console.log(data);
                var auth_token = loginData.auth_token;
                console.log("got auth token=" + auth_token);
            
                
                var siteData = [];
                
                var emailerrormsg = '';
                
                
                var ohpData = await trackoGetSummaryDataForSitePromise(auth_token,ohp_site_id,startEpoch,endEpoch);
                //console.log("Ohp data===",ohpData);
               
                // Parse the JSON data to get an object
                if (typeof ohpData === 'string'){
                  ohpData = JSON.parse(ohpData);
                }
                // The site ID you want to check
                ohp_site_id = "fa423a8e55";
                
                // Debug: Print the keys of ohpData
                console.log("Keys in ohpData:", Object.keys(ohpData));
                
                // Check if the site ID exists in the data
                const ohpId = ohpData.hasOwnProperty(ohp_site_id);
                console.log("ohpData Id:", ohpId);
                
                
                if (ohpId) {
                    //console.log(`Data for site ${ohp_site_id}: `, ohpData[ohp_site_id]);
                    console.log("1. OHP")
                    siteData.push({'OHP' : true});
                    
                } else if (ohpData.error) {
                    console.log(`Error: Data of site id ${ohp_site_id} not found.`);
                    siteData.push({'OHP' : false});
                    //sendMail(emailIDArr, subject, mailContent, callback)
                    const emailerrormsg = `<br> <b>Octopus has detected that the data of OHP has some error named ${ohpData.error} </b><br>`;
                    console.error(emailerrormsg);
                    emailerrorlist.push(emailerrormsg);
                    
                } else {
                    console.log(`Error: Data of site id ${ohp_site_id} not found 2.`);
                    siteData.push({'OHP' : false});
                    //sendMail(emailIDArr, subject, mailContent, callback)
                    const emailerrormsg = `<br> Octopus has detected that the data of OHP has some error ${ohpData.error}.</b><br>`;
                    console.error(emailerrormsg);
                    emailerrorlist.push(emailerrormsg);
                }
                               
               
              //-------------------------------------------------------------------------
                var janaData = await trackoGetSummaryDataForSitePromise(auth_token,jana_site_id,startEpoch,endEpoch);
                //console.log("janaData===",janaData);
                
                // Parse the JSON data to get an object
                if (typeof janaData === 'string'){
                  janaData = JSON.parse(janaData);
                }
                // The site ID you want to check
                jana_site_id = "05e17b0001";
                
                
                // Debug: Print the keys of ohpData
                console.log("Keys in janaData:", Object.keys(janaData));
                
                // Check if the site ID exists in the data
                const janaId = janaData.hasOwnProperty(jana_site_id);
                console.log("janaData Id:", janaId);
                
                if (janaId) {
                    //console.log(`Data for site ${jana_site_id}: `, janaData[jana_site_id]);
                    console.log("2. JANA")
                        siteData.push({'JANA' : true});
                } else if (janaData.error) {
                    console.log(`Error: Data of site id ${jana_site_id} not found.`);
                    siteData.push({'JANA' : false});
                    const emailerrormsg = `<br> <b>Octopus has detected that the data of JANA has some error named ${janaData.error} </b><br>`;
                    console.error(emailerrormsg);
                    emailerrorlist.push(emailerrormsg);
                    
                } else {
                    console.log(`Error: Data of site id ${jana_site_id} not found 2.`);
                    siteData.push({'JANA' : false});
                    const emailerrormsg = `<br> <b>Octopus has detected that the data of JANA has some error named ${janaData.error} </b><br>`;
                    console.error(emailerrormsg);
                    emailerrorlist.push(emailerrormsg);
                }
                
                // // console.log("siteData===+",siteData)
                // //--------------------------------------------------------------------------
                
                var meadowsData = await trackoGetSummaryDataForSitePromise(auth_token,meadows_site_id,startEpoch,endEpoch);
                //console.log("meadowsData====",meadowsData);
                // Parse the JSON data to get an object
                if (typeof meadowsData === 'string'){
                  meadowsData = JSON.parse(meadowsData);
                }
                // The site ID you want to check
                meadows_site_id = "01b9e18a21";
                
                console.log("Keys in meadowsData:", Object.keys(meadowsData));
                
                // Check if the site ID exists in the data
                const meadowsId = meadowsData.hasOwnProperty(meadows_site_id);
                console.log("meadowsData Id:", meadowsId);
                
                if (meadowsId) {
                    //console.log(`Data for site ${meadows_site_id}: `, meadowsData[meadows_site_id]);
                    console.log("3. MEADOWS")
                    siteData.push({'MEADOWS' : true});
                } else if (meadowsData.error) {
                    console.log(`Error: Data of site id ${meadows_site_id} not found.`);
                    siteData.push({'MEADOWS' : false});
                    const emailerrormsg = `<br> <b>Octopus has detected that the data of MEADOWS has some error named ${meadowsData.error} </b><br>`;
                    console.error(emailerrormsg);
                    emailerrorlist.push(emailerrormsg);
                    
                } else {
                    console.log(`Error: Data of site id ${meadows_site_id} not found 2.`);
                    siteData.push({'MEADOWS' : false});
                    const emailerrormsg = `<br> <b>Octopus has detected that the data of MEADOWS has some error named ${meadowsData.error} </b><br>`;
                    console.error(emailerrormsg);
                    emailerrorlist.push(emailerrormsg);
                }
                // // //--------------------------------------------------------------------------
                var cliftonData = await trackoGetSummaryDataForSitePromise(auth_token,clifton_site_id,startEpoch,endEpoch);
                //console.log("cliftonData===",cliftonData);
                // Parse the JSON data to get an object
                if (typeof cliftonData === 'string'){
                  cliftonData = JSON.parse(cliftonData);
                }
                // The site ID you want to check
                clifton_site_id = "82580871dd";
                
                
                // Debug: Print the keys of ohpData
                console.log("Keys in cliftonData:", Object.keys(cliftonData));
                
                // Check if the site ID exists in the data
                const cliftonId = cliftonData.hasOwnProperty(clifton_site_id);
                console.log("cliftonData Id:", cliftonId);
                
                if (cliftonId) {
                    //console.log(`Data for site ${clifton_site_id}: `, cliftonData[clifton_site_id]);
                    console.log("4.CLIFTON")
                        siteData.push({'CLIFTON' : true});
                } else if (cliftonData.error) {
                    console.log(`Error: Data of site id ${clifton_site_id} not found.`);
                    siteData.push({'CLIFTON' : false});
                    const emailerrormsg = `<br> <b>Octopus has detected that the data of CLIFTON has some error named ${cliftonData.error} </b><br>`;
                    console.error(emailerrormsg);
                    emailerrorlist.push(emailerrormsg);
                    
                } else {
                    console.log(`Error: Data of site id ${clifton_site_id} not found 2.`);
                    siteData.push({'CLIFTON' : false});
                    const emailerrormsg = `<br> <b>Octopus has detected that the data of CLIFTON has some error named ${cliftonData.error} </b><br>`;
                    console.error(emailerrormsg);
                    emailerrorlist.push(emailerrormsg);
                }
                // // //--------------------------------------------------------------------------
                var npData = await trackoGetSummaryDataForSitePromise(auth_token,np_site_id,startEpoch,endEpoch);
                //console.log("npData===",npData);
                // Parse the JSON data to get an object
                if (typeof npData === 'string'){
                  npData = JSON.parse(npData);
                }
                // The site ID you want to check
                np_site_id = "a48403f527";
                
                
                // Debug: Print the keys of ohpData
                console.log("Keys in npData:", Object.keys(npData));
                
                // Check if the site ID exists in the data
                const npId = npData.hasOwnProperty(np_site_id);
                console.log("npData Id:", npId);
                
                if (npId) {
                    //console.log(`Data for site ${np_site_id}: `, npData[np_site_id]);
                    console.log("5. NP")
                        siteData.push({'NP' : true});
                } else if (npData.error) {
                    console.log(`Error: Data of site id ${np_site_id} not found.`);
                    
                    siteData.push({'NP' : false});
                    const emailerrormsg = `<br> <b>Octopus has detected that the data of NP has some error named ${npData.error} </b><br>`;
                    console.error(emailerrormsg);
                    emailerrorlist.push(emailerrormsg);
                    
                } else {
                    console.log(`Error: Data of site id ${np_site_id} not found 2.`);
                    siteData.push({'NP' : false});
                    const emailerrormsg = `<br> <b>Octopus has detected that the data of NP has some error named ${npData.error} </b><br>`;
                    console.error(emailerrormsg);
                    emailerrorlist.push(emailerrormsg);
                }
                // // //--------------------------------------------------------------------------
                var zeniaData = await trackoGetSummaryDataForSitePromise(auth_token,zenia_site_id,startEpoch,endEpoch);
                //console.log("zeniaData===",zeniaData);
                // Parse the JSON data to get an object
                if (typeof zeniaData === 'string'){
                  zeniaData = JSON.parse(zeniaData);
                }
                // The site ID you want to check
                zenia_site_id = "25041efc9b";
                
                // Debug: Print the keys of ohpData
                console.log("Keys in zeniaData:", Object.keys(zeniaData));
                
                // Check if the site ID exists in the data
                const zeniaId = zeniaData.hasOwnProperty(zenia_site_id);
                console.log("zeniaData Id:", zeniaId);
                
                if (zeniaId) {
                    //console.log(`Data for site ${zenia_site_id}: `, zeniaData[zenia_site_id]);
                    console.log("6. ZENIA")
                        siteData.push({'ZENIA' : true});
                } else if (zeniaData.error) {
                    console.log(`Error: Data of site id ${zenia_site_id} not found.`);
                    siteData.push({'ZENIA' : false});
                    const emailerrormsg = `<br> <b>Octopus has detected that the data of ZENIA has some error named ${zeniaData.error} </b><br>`;
                    console.error(emailerrormsg);
                    emailerrorlist.push(emailerrormsg);
                    
                } else {
                    console.log(`Error: Data of site id ${zenia_site_id} not found 2.`);
                    siteData.push({'ZENIA' : false});
                    const emailerrormsg = `<br> <b>Octopus has detected that the data of ZENIA has some error named ${zeniaData.error} </b><br>`;
                    console.error(emailerrormsg);
                    emailerrorlist.push(emailerrormsg);
                }
                // // //--------------------------------------------------------------------------
                var bellonaData = await trackoGetSummaryDataForSitePromise(auth_token,bellona_site_id,startEpoch,endEpoch);
                //console.log("bellonaData===",bellonaData);
                // Parse the JSON data to get an object
                if (typeof bellonaData === 'string'){
                  bellonaData = JSON.parse(bellonaData);
                }
                // The site ID you want to check
                bellona_site_id = "ba468d52e2";
                
                
                // Debug: Print the keys of ohpData
                console.log("Keys in bellonaData:", Object.keys(bellonaData));
                
                // Check if the site ID exists in the data
                const bellonaId = bellonaData.hasOwnProperty(bellona_site_id);
                console.log("bellonaData Id:", bellonaId);
                
                if (bellonaId) {
                    //console.log(`Data for site ${bellona_site_id}: `, bellonaData[bellona_site_id]);
                    console.log("7. BELLONA")
                        siteData.push({'BELLONA' : true});
                } else if (bellonaData.error) {
                    console.log(`Error: Data of site id ${bellona_site_id} not found.`);
                    siteData.push({'BELLONA' : false});
                    const emailerrormsg = `<br> <b>Octopus has detected that the data of BELLONA has some error named ${bellonaData.error} </b><br>`;
                    console.error(emailerrormsg);
                    emailerrorlist.push(emailerrormsg);
                    
                } else {
                    console.log(`Error: Data of site id ${bellona_site_id} not found 2.`);
                    siteData.push({'BELLONA' : false});
                    const emailerrormsg = `<br> <b>Octopus has detected that the data of BELLONA has some error named ${bellonaData.error} </b><br>`;
                    console.error(emailerrormsg);
                    emailerrorlist.push(emailerrormsg);
                }
              
                // // //--------------------------------------------------------------------------
                var quantumData = await trackoGetSummaryDataForSitePromise(auth_token,quantum_site_id,startEpoch,endEpoch);
                //console.log("quantumData===",quantumData);
                // Parse the JSON data to get an object
                if (typeof quantumData === 'string'){
                  quantumData = JSON.parse(quantumData);
                }
                // The site ID you want to check
                quantum_site_id = "034e55921c";
                
                
                // Debug: Print the keys of ohpData
                console.log("Keys in quantumData:", Object.keys(quantumData));
                
                // Check if the site ID exists in the data
                const quantumId = quantumData.hasOwnProperty(quantum_site_id);
                console.log("quantumData Id:", quantumId);
                
                if (quantumId) {
                    //console.log(`Data for site ${quantum_site_id}: `, quantumData[quantum_site_id]);
                    console.log("8. QUANTUM")
                        siteData.push({'QUANTUM' : true});
                 
                } else if (quantumData.error) {
                    console.log(`Error: Data of site id ${quantum_site_id} not found.`);
                    siteData.push({'QUANTUM' : false});
                    const emailerrormsg = `<br> <b>Octopus has detected that the data of QUANTUM has some error named ${quantumData.error} </b><br>`;
                    console.error(emailerrormsg);
                    emailerrorlist.push(emailerrormsg);
                    
                } else {
                    console.log(`Error: Data of site id ${quantum_site_id} not found 2.`);
                    siteData.push({'QUANTUM' : false});
                    const emailerrormsg = `<br> <b>Octopus has detected that the data of QUANTUM has some error named ${quantumData.error} </b><br>`;
                    console.error(emailerrormsg);
                    emailerrorlist.push(emailerrormsg);
                }
                // //--------------------------------------------------------------------------
                var tiffanyData = await trackoGetSummaryDataForSitePromise(auth_token,tiffany_site_id,startEpoch,endEpoch);
                console.log("tiffanyData===",tiffanyData);
                //console.log("tiffanyData.error===",tiffanyData.error)
               
                // Parse the JSON data to get an object
                if (typeof tiffanyData === 'string') {
                    tiffanyData = JSON.parse(tiffanyData);
                }
                
                // The site ID you want to check
                tiffany_site_id = "375a9e9d80";
                
                // Debug: Print the entire ohpData object
                //console.log("tiffanyData:", JSON.stringify(tiffanyData, null, 2));
                
                // Debug: Print the site ID
                //console.log("tiffany_site_id:", tiffany_site_id);
                
                // Debug: Print the type of site ID
                //console.log("tiffany_site_id type:", typeof(tiffany_site_id));
                
                // Debug: Print the keys of ohpData
                console.log("Keys in tiffanyData:", Object.keys(tiffanyData));
                
                // Check if the site ID exists in the data
                const tiffanyId = tiffanyData.hasOwnProperty(tiffany_site_id);
                console.log("tiffanyData Id:", tiffanyId);
                
                if (tiffanyId) {
                    //onsole.log(`Data for site ${tiffany_site_id}: `, tiffanyData[tiffany_site_id]);
                    console.log("9. TIFFANY")
                    siteData.push({'TIFFANY' : true});
                } else if (tiffanyData.error) {
                    console.log(`Error: Data of site id ${tiffany_site_id} not found.`);
                    siteData.push({'TIFFANY' : false});
                    //sendMail(emailIDArr, subject, mailContent, callback)
                    const emailerrormsg = `<br> <b>Octopus has detected that the data of TIFFANY has some error named ${tiffanyData.error} </b><br>`;
                    console.error(emailerrormsg);
                    emailerrorlist.push(emailerrormsg);
                    
                } else {
                    console.log(`Error: Data of site id ${tiffany_site_id} not found 2.`);
                    siteData.push({'TIFFANY' : false});
                    //sendMail(emailIDArr, subject, mailContent, callback)
                    const emailerrormsg = `<br> <b>Octopus has detected that the data of TIFFANY has some error named ${tiffanyData.error} </b><br>`;
                    console.error(emailerrormsg);
                    emailerrorlist.push(emailerrormsg);
                }
               
                // //--------------------------------------------------------------------------
                var hamiltonAData = await trackoGetSummaryDataForSitePromise(auth_token,hamiltonA_site_id,startEpoch,endEpoch);
                //console.log("hamiltonAData===",hamiltonAData);
                // Parse the JSON data to get an object
                if (typeof hamiltonAData === 'string') {
                    hamiltonAData = JSON.parse(hamiltonAData);
                }
                
                // The site ID you want to check
                hamiltonA_site_id = "990201078b";
                
                // Debug: Print the entire ohpData object
                //console.log("hamiltonAData:", JSON.stringify(hamiltonAData, null, 2));
                
                // Debug: Print the site ID
                //console.log("hamiltonA_site_id:", hamiltonA_site_id);
                
                // Debug: Print the type of site ID
                console.log("hamiltonA_site_id type:", typeof(hamiltonA_site_id));
                
                // Debug: Print the keys of ohpData
                console.log("Keys in hamiltonAData:", Object.keys(hamiltonAData));
                
                // Check if the site ID exists in the data
                const hamiltonAId = hamiltonAData.hasOwnProperty(hamiltonA_site_id);
                console.log("hamiltonAData Id:", hamiltonAId);
                
                if (hamiltonAId) {
                    //console.log(`Data for site ${hamiltonA_site_id}: `, hamiltonAData[hamiltonA_site_id]);
                    console.log("10. HAMILTON_A")
                    siteData.push({'HAMILTON_A' : true});
                } else if (hamiltonAData.error) {
                    console.log(`Error: Data of site id ${hamiltonA_site_id} not found.`);
                    siteData.push({'HAMILTON_A' : false});
                    const emailerrormsg = `<br> <b>Octopus has detected that the data of HAMILTON_A has some error named ${hamiltonAData.error} </b><br>`;
                    console.error(emailerrormsg);
                    emailerrorlist.push(emailerrormsg);
                    
                } else {
                    console.log(`Error: Data of site id ${hamiltonA_site_id} not found 2.`);
                    siteData.push({'HAMILTON_A' : false});
                    const emailerrormsg = `<br> <b>Octopus has detected that the data of HAMILTON_A has some error named ${hamiltonAData.error} </b><br>`;
                    console.error(emailerrormsg);
                    emailerrorlist.push(emailerrormsg);
                }
                //---------------------------------------------------------------
                
                
                //console.log("siteData===+",siteData)
                console.log("Emailerrorlist",emailerrorlist)
                console.log("Hiiii")
                
                // Send alert to mail each condition
                console.log("emailerrorlist.length",emailerrorlist.length)
                if(emailerrorlist.length > 0){
                    
                 // sendMail(emailIDArr,subject,emailerrorlist,callback)
                        const mailContent = await mailcontent(emailerrorlist);
        
                        // Send email with HTML content
                        await sendMail(emailIDArr, subject, mailContent,callback);
                }  
                else{
                    console.log("Error in mail sending")
                    
                }

                
                async function trackoGetSummaryDataForSitePromise(auth_token,site_id,startEpoch,endEpoch){
   
                   var options = {
                      'method': 'POST',
                      'hostname': 'integrationsapi.trackso.in',
                      'path': '/integrations/v1/site_data',
                      'headers': {
                        'X-Api-Key': 'd1de0bb24505fbd0eabb713d27d07d81f239b893',
                        'X-Auth-Token': auth_token,
                        'Content-Type': 'application/json'
                      },
                    'maxRedirects': 20
                    };
                    
                    return new Promise((resolve, reject) => {
                        var req = https.request(options, function (res) {
                            var chunks = [];
                    
                            res.on("data", function (chunk) {
                                chunks.push(chunk);
                            });
                    
                            res.on("end", function (chunk) {
                                var body = Buffer.concat(chunks);
                                
                                // console.log(body.toString());
                                resolve(body.toString());
                            });
                    
                            res.on("error", function (error) {
                                console.error(error);
                                callback(error);
                            });
                        });
                    
                        var postData = JSON.stringify({
                            "sites": {
                                [site_id]: {
                                  "Daily Energy": "max",
                                  "Total Energy": "last"
                                }
                            },
                            "from": startEpoch,
                            "to": endEpoch,
                            "time_grouping": "day"
                        });
                    
                        req.write(postData);
                    
                        req.end();
                    });
                
                    
                }
                
                
            })
            }
            catch(e){
                console.log(e.stack);
               
            }
        
                        
}

async function mailcontent(emailerrorlist) {
    let mailContent = `<html>`;
    mailContent += `<body>`;
    mailContent += `<h2 style="color:darkgreen">Trackso API Data </h2>`;
    mailContent += `<table id="octopus-table" border=1 bordercolor="#fff" cellspacing=0 cellpadding=15 style="border-radius:15px">`;
    mailContent += `<tr style="background-color:black;color:#fff" class='tableheader'>`;
    mailContent += `<th colspan=3>Trackso API Alert</th>`;
    mailContent += `</tr>`;
    mailContent += `<tr style="background-color:black;color:#fff" class='tableheader'>`;
    mailContent += `<th style="text-align:center;background-color:green;color:#fff">Problem Detected with Trackso API</th>`;
    mailContent += `</tr>`;

    // Append dynamic table rows based on errorlist
    emailerrorlist.forEach(error => {
        mailContent += `<tr>`;
        mailContent += `<td style="background-color:orange;color:#fff"><b>${error}</b></td>`;
        mailContent += `</tr>`;
    });


    // Close HTML body and table tags
    mailContent += `</table>`;
    mailContent += `<br/><br/><img id="kidsImg" style="width:300px;height:auto;align:center;" src="https://www.octopus-automation.com/apps/eqi/images/kids.png"/>`;
    mailContent += `&nbsp; &nbsp; <img id="logoImg" src="https://www.octopus-automation.com/apps/eqi/images/octopus-logo-dark-hoh.png" style="width:150px;height:auto;align:center;"/>`;
    mailContent += `<h5>"CLEANER ENVIRONMENT FOR FUTURE GENERATIONS"</h5>`;
    mailContent += `<span class="smallText lighText" style="font-size:.9em;color:grey;">This is an automated email from the Octopus system. Please donot reply to this email</span>`;
    mailContent += `</body>`;
    mailContent += `</html>`;

    return mailContent;
}
         // Assuming you have a sendMail function defined
 async function sendMail(emailIDArr, subject, mailContent, callback) {
    // Construct email parameters
    var params = {
        Destination: {
            ToAddresses: emailIDArr
        },
        Message: {
            Body: {
                Html: {
                    Charset: "UTF-8",
                    Data: mailContent
                }
            },
            Subject: {
                Charset: "UTF-8",
                Data: subject
            }
        },
        Source: "octopus-alerts@octopusio.io" 
    };
    
 
    
     // Send the email
    ses.sendEmail(params, function (err, data) {
        if (err) {
            console.error('Error sending email', err);
            callback("Error sending email");
        } else {
            console.log('Email sent successfully', data);
            callback(null, "Mail sent successfully");
        }
    });               
 } 
 



 
 
function formatDate(date) {
var d = new Date(date),
    month = '' + (d.getMonth() + 1),
    day = '' + d.getDate(),
    year = d.getFullYear();

if (month.length < 2) 
    month = '0' + month;
if (day.length < 2) 
    day = '0' + day;

return [year, month, day].join('-');
}


function formatDateFancy(date) {
var d = new Date(date),
    month = '' + (d.getMonth() + 1),
    day = '' + d.getDate(),
    year = d.getFullYear().toString().substr(-2);
    
    const monthName = d.toLocaleString('default', { month: 'short' });
    const dayName = d.toLocaleString('default', { weekday: 'short' });

if (month.length < 2) 
    month = '0' + month;
if (day.length < 2) 
    day = '0' + day;

return [day, month, year].join('-');
// return `${dayName}, ${day} ${monthName}, ${year}`;
}

function tracksoLogin(callback){
        var options = {
          'method': 'POST',
          'hostname': 'integrationsapi.trackso.in',
          'path': '/integrations/v1/api_sign_in',
          'headers': {
            'X-Api-Key': 'd1de0bb24505fbd0eabb713d27d07d81f239b893',
            'Content-Type': 'application/json'
          },
          'maxRedirects': 20
        };
        
        
        var req = https.request(options, function (res) {
        var chunks = [];
        
            res.on("data", function (chunk) {
                chunks.push(chunk);
            });
            
            res.on("end", function (chunk) {
                var body = Buffer.concat(chunks);
                body = body.toString();
                // console.log(body.toString());
                callback(null,body);
            });
            
            res.on("error", function (error) {
                // console.error(error);
                callback(error);
            });
        });
        
        var postData = JSON.stringify({
        "email": "gyansingh.jat@houseofhiranandani.com",
        "password": "@newPassword#"
        });
        
        req.write(postData);
        
        req.end();
}


function trackoGetSummaryDataForSite(auth_token,site_id,startEpoch,endEpoch,callback){
   
   var options = {
      'method': 'POST',
      'hostname': 'integrationsapi.trackso.in',
      'path': '/integrations/v1/site_data',
      'headers': {
        'X-Api-Key': 'd1de0bb24505fbd0eabb713d27d07d81f239b893',
        'X-Auth-Token': auth_token,
        'Content-Type': 'application/json'
      },
    'maxRedirects': 20
    };

    var req = https.request(options, function (res) {
        var chunks = [];

        res.on("data", function (chunk) {
            chunks.push(chunk);
        });

        res.on("end", function (chunk) {
            var body = Buffer.concat(chunks);
            // console.log(body.toString());
            callback(null,body.toString());
        });

        res.on("error", function (error) {
            console.error(error);
            callback(error);
        });
    });

    var postData = JSON.stringify({
        "sites": {
            [site_id]: {
              "Daily Energy": "max",
              "Total Energy": "last"
            }
        },
        "from": startEpoch,
        "to": endEpoch,
        "time_grouping": "day"
    });

    req.write(postData);

    req.end();
}

function extractSolarData(data,site_id,unitCost,capex,installedCapacity,installedDate){
    data = JSON.parse(data);
    var yesterdayEnergy = data[site_id].data[0].value;
    var yesterdayUnits = data[site_id].data[0].unit_of_measure;
    var yesterdayCost = 0;
    
    
    if(yesterdayUnits.toLowerCase() == "kwh"){
        yesterdayCost = yesterdayEnergy * unitCost;
    }
    else if(yesterdayUnits.toLowerCase() == "mwh"){
        yesterdayCost = yesterdayEnergy * 1000 * unitCost;
    }
    
    var totalEnergy = data[site_id].data[1].value;
    var totalUnits = data[site_id].data[1].unit_of_measure;
    var totalCost = 0;
    
    if(totalUnits.toLowerCase() == "kwh"){
        totalCost = totalEnergy * unitCost;
    }
    else if(totalUnits.toLowerCase() == "mwh"){
        totalCost = totalEnergy * 1000 * unitCost;
    }
    
    const capexRecoveredPercentage = (totalCost * 100) / capex;
    
    return {
            "yesterdayEnergy" : yesterdayEnergy,
            "yesterdayUnits" : yesterdayUnits,
            "yesterdayCost" : yesterdayCost,
            "totalEnergy" : totalEnergy,
            "totalUnits" : totalUnits,
            "totalCost" : totalCost,
            "capexCost" : capex,
            "capexRecoveredPercentage" : capexRecoveredPercentage,
            "installedCapacity" : installedCapacity,
            "installedDate" : installedDate
    }
}
                      